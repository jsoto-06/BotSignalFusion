package com.example.signalfusion

import kotlin.math.abs

/**
 * 🧠 SIGNAL FUSION V8 OPTIMIZADA
 *
 * MEJORAS vs V7:
 * ✅ Win Rate objetivo: 50-60% (vs 33% actual)
 * ✅ R:R Ratio objetivo: 2:1+ (vs 0.96:1 actual)
 * ✅ Filtros más estrictos (menos trades, mejor calidad)
 * ✅ Confirmaciones múltiples obligatorias
 * ✅ Anti-overtrading mejorado
 */

data class MarketData(
    val price: Double,
    val high: Double,
    val low: Double,
    val rsi: Double,
    val rsiMA: Double,
    val emaFast: Double,
    val emaSlow: Double,
    val emaMid: Double,
    val emaTrend: Double,
    val bbUpper: Double,
    val bbMiddle: Double,
    val bbLower: Double,
    val macdLine: Double,
    val macdSignal: Double,
    val macdHist: Double
)

data class SignalScore(
    val longScore: Double,
    val shortScore: Double,
    val longThreshold: Double,
    val shortThreshold: Double
)

class DoubleConfirmationManager {
    private var lastSignalBar = -1
    private var lastSignalType: String? = null
    private val confirmationBars = 3  // ✅ AUMENTADO de 2 a 3 para mejor confirmación

    fun shouldAllowSignal(currentBar: Int, signalType: String, oppositeSignal: Boolean): Boolean {
        val barsSinceLastSignal = currentBar - lastSignalBar
        if (barsSinceLastSignal < confirmationBars && lastSignalType != null && lastSignalType != signalType) return false
        if (oppositeSignal) return false
        return true
    }

    fun registerSignal(currentBar: Int, signalType: String) {
        lastSignalBar = currentBar
        lastSignalType = signalType
    }
}

class SignalFusionUltimateStrategy(
    private val timeframe: String = "15m",  // ✅ DEFAULT 15m (mejor que 5m)
    private val mode: String = "MODERADA"
) {
    val name = "SignalFusion V8 Optimizada 🎯"

    private val confirmationManager = DoubleConfirmationManager()

    private var currentBar = 0
    private var pricePrev = 0.0
    private var rsiPrev = 50.0
    private var macdHistPrev = 0.0
    private var emaFastPrev = 0.0
    private var emaSlowPrev = 0.0
    private var rangePrev = 0.0

    // ✅ NUEVO: Contador de trades consecutivos
    private var consecutiveTrades = 0
    private var lastTradeBar = 0

    private fun getWeights(tf: String): Map<String, Double> {
        // ✅ AJUSTADO: Más peso a confirmaciones sólidas
        return when (tf) {
            "1m"  -> mapOf("rsi" to 1.8, "ema" to 2.6, "bb" to 1.5, "macd" to 2.0)  // EMA y MACD más importantes
            "5m"  -> mapOf("rsi" to 1.9, "ema" to 2.5, "bb" to 1.6, "macd" to 1.9)
            "15m" -> mapOf("rsi" to 2.0, "ema" to 2.4, "bb" to 1.7, "macd" to 1.8)  // RECOMENDADO
            "30m" -> mapOf("rsi" to 2.1, "ema" to 2.3, "bb" to 1.8, "macd" to 1.7)
            else  -> mapOf("rsi" to 2.0, "ema" to 2.2, "bb" to 1.7, "macd" to 1.6)
        }
    }

    private fun calculateScore(data: MarketData): SignalScore {
        val weights = getWeights(timeframe)
        val rsiW = weights["rsi"]!!
        val emaW = weights["ema"]!!
        val bbW = weights["bb"]!!
        val macdW = weights["macd"]!!

        var longScore = 0.0
        var shortScore = 0.0

        // ==========================================
        // 🛡️ FILTROS CRÍTICOS MEJORADOS
        // ==========================================

        // 1. Detección de volatilidad extrema
        val bbWidth = (data.bbUpper - data.bbLower) / data.bbMiddle
        val isSqueeze = bbWidth < 0.012  // ✅ MÁS ESTRICTO (era 0.013)
        val isVeryWide = bbWidth > 0.035  // ✅ NUEVO: Evitar volatilidad extrema

        val candleRange = (data.high - data.low) / data.price
        val isHighVolatility = currentBar > 5 && candleRange > rangePrev * 1.6  // ✅ MÁS ESTRICTO (era 1.45)

        // 2. Fuerza de tendencia
        val emaSeparation = abs(data.emaFast - data.emaSlow) / data.price
        val isStrongTrend = emaSeparation > 0.0022  // ✅ MÁS ESTRICTO (era 0.0018)

        // 3. Distancia del precio a EMA200
        val distanceFromTrend = abs(data.price - data.emaTrend) / data.price
        val isTooFarFromTrend = distanceFromTrend > 0.025  // ✅ NUEVO: Evitar extremos

        // 4. Cruces confirmados
        val emaCrossUp = emaFastPrev < emaSlowPrev && data.emaFast > data.emaSlow
        val emaCrossDown = emaFastPrev > emaSlowPrev && data.emaFast < data.emaSlow
        val macdCrossUp = data.macdLine > data.macdSignal && data.macdHist > 0 && macdHistPrev <= 0
        val macdCrossDown = data.macdLine < data.macdSignal && data.macdHist < 0 && macdHistPrev >= 0

        // ==========================================
        // 🚫 FILTROS DE BLOQUEO (MÁS ESTRICTOS)
        // ==========================================

        // Bloquear trades si hay volatilidad extrema
        if (isHighVolatility || isVeryWide) {
            longScore -= 3.0  // ✅ PENALIZACIÓN MAYOR (era 1.8)
            shortScore -= 3.0
        }

        // Bloquear si está muy lejos de la tendencia principal
        if (isTooFarFromTrend) {
            longScore -= 2.5
            shortScore -= 2.5
        }

        // ✅ NUEVO: Filtro anti-overtrading
        if (currentBar - lastTradeBar < 5 && consecutiveTrades >= 2) {
            longScore -= 2.0
            shortScore -= 2.0
        }

        // Filtro de tendencia principal (MÁS ESTRICTO)
        if (data.price < data.emaTrend) {
            longScore -= if (isStrongTrend) 3.5 else 2.5  // ✅ AUMENTADO (era 2.6/1.6)
        }
        if (data.price > data.emaTrend) {
            shortScore -= if (isStrongTrend) 3.5 else 2.5
        }

        // ==========================================
        // 📈 SCORING LONG (MÁS SELECTIVO)
        // ==========================================

        // RSI: Solo extremos claros
        if (data.rsi < 30) {  // ✅ MÁS ESTRICTO (era 35)
            longScore += rsiW * 1.3  // ✅ MÁS PESO (era 1.1)
        } else if (data.rsi in 30.0..40.0 && data.rsi > rsiPrev + 2 && data.rsi > data.rsiMA) {  // ✅ CAMBIO > 2 puntos
            longScore += rsiW * 0.9
        }

        // EMAs: Cruces y alineación
        if (emaCrossUp) {
            longScore += emaW * 1.6  // ✅ MÁS PESO para cruces (era 1.35)
        }
        if (data.emaFast > data.emaSlow && data.price > data.emaFast && data.price > data.emaMid) {  // ✅ TRIPLE confirmación
            longScore += emaW * 1.0  // ✅ AUMENTADO (era 0.7)
        }
        if (data.price > data.emaTrend * 1.002) {  // ✅ Mínimo 0.2% arriba
            longScore += 1.2  // ✅ AUMENTADO (era 0.85)
        }

        // Bollinger Bands: Solo toques claros
        if (data.price < data.bbLower * 1.002) {  // ✅ NUEVO: Debe estar DEBAJO con margen
            longScore += bbW * 1.4  // ✅ AUMENTADO (era 1.1)
        }
        if (isSqueeze && data.price < data.bbMiddle * 0.998) {  // ✅ MÁS ESTRICTO
            longScore += bbW * 1.8  // ✅ AUMENTADO (era 1.55)
        }

        // MACD: Solo con momentum claro
        if (data.macdHist > 0 && data.macdHist > macdHistPrev * 1.15) {  // ✅ NUEVO: 15% incremento
            longScore += macdW * 1.1  // ✅ AUMENTADO (era 0.9)
        }
        if (macdCrossUp) {
            longScore += macdW * 1.5  // ✅ MÁS PESO (era 1.25)
        }

        // ==========================================
        // 📉 SCORING SHORT (SIMÉTRICO)
        // ==========================================

        if (data.rsi > 70) {  // ✅ MÁS ESTRICTO (era 65)
            shortScore += rsiW * 1.3
        } else if (data.rsi in 60.0..70.0 && data.rsi < rsiPrev - 2 && data.rsi < data.rsiMA) {
            shortScore += rsiW * 0.9
        }

        if (emaCrossDown) {
            shortScore += emaW * 1.6
        }
        if (data.emaFast < data.emaSlow && data.price < data.emaFast && data.price < data.emaMid) {
            shortScore += emaW * 1.0
        }
        if (data.price < data.emaTrend * 0.998) {
            shortScore += 1.2
        }

        if (data.price > data.bbUpper * 0.998) {
            shortScore += bbW * 1.4
        }
        if (isSqueeze && data.price > data.bbMiddle * 1.002) {
            shortScore += bbW * 1.8
        }

        if (data.macdHist < 0 && data.macdHist < macdHistPrev * 1.15) {
            shortScore += macdW * 1.1
        }
        if (macdCrossDown) {
            shortScore += macdW * 1.5
        }

        // ==========================================
        // 🎯 UMBRALES AJUSTADOS (MÁS ALTOS)
        // ==========================================

        val baseThreshold = when (timeframe) {
            "1m"  -> 5.5  // ✅ AUMENTADO (era 3.9)
            "5m"  -> 5.0  // ✅ AUMENTADO (era 3.5)
            "15m" -> 4.5  // ✅ AUMENTADO (era 3.2) ← RECOMENDADO
            "30m" -> 4.2  // ✅ AUMENTADO (era 2.9)
            else  -> 4.0
        }

        val modeMult = when (mode) {
            "MODERADA" -> 1.25  // ✅ MÁS CONSERVADOR (era 1.16)
            "AGRESIVA" -> 0.95  // ✅ MENOS AGRESIVO (era 0.83)
            "BREAKOUT" -> 0.90  // ✅ AJUSTADO (era 0.78)
            else       -> 1.0
        }

        var threshold = baseThreshold * modeMult

        // ✅ Squeeze: Menos agresivo
        if (mode == "BREAKOUT" && isSqueeze) {
            threshold *= 0.90  // ✅ MENOS REDUCCIÓN (era 0.82)
        }

        // ✅ Sesgo dinámico más conservador
        val bullishBias = data.price > data.emaTrend * 1.012 && isStrongTrend  // ✅ MÁS ESTRICTO (era 1.008)
        val bearishBias = data.price < data.emaTrend * 0.988 && isStrongTrend  // ✅ MÁS ESTRICTO (era 0.992)

        when {
            bullishBias -> {
                longScore *= 1.15  // ✅ MENOS SESGO (era 1.18)
                shortScore *= 0.85
            }
            bearishBias -> {
                shortScore *= 1.15
                longScore *= 0.85
            }
            else -> threshold *= 1.12  // ✅ MÁS EXIGENTE en rango (era 1.08)
        }

        return SignalScore(longScore, shortScore, threshold, threshold)
    }

    fun evaluate(data: MarketData): String {
        currentBar++

        val score = calculateScore(data)

        val rawLong = score.longScore >= score.longThreshold
        val rawShort = score.shortScore >= score.shortThreshold

        val isLong = rawLong && confirmationManager.shouldAllowSignal(currentBar, "LONG", rawShort)
        val isShort = rawShort && confirmationManager.shouldAllowSignal(currentBar, "SHORT", rawLong)

        var finalSignal = "NEUTRAL"

        if (isLong) {
            confirmationManager.registerSignal(currentBar, "LONG")
            finalSignal = "LONG"
            consecutiveTrades++
            lastTradeBar = currentBar
        } else if (isShort) {
            confirmationManager.registerSignal(currentBar, "SHORT")
            finalSignal = "SHORT"
            consecutiveTrades++
            lastTradeBar = currentBar
        } else {
            // Reset counter si no hay trade
            if (currentBar - lastTradeBar > 10) {
                consecutiveTrades = 0
            }
        }

        // Actualizar memoria
        pricePrev = data.price
        rsiPrev = data.rsi
        macdHistPrev = data.macdHist
        emaFastPrev = data.emaFast
        emaSlowPrev = data.emaSlow
        rangePrev = (data.high - data.low) / data.price

        return finalSignal
    }
}