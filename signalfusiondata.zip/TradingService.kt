// 🚀 TRADING SERVICE V7.4 - FIX MINIMUM AMOUNT 🚀
package com.example.signalfusion

import android.app.*
import android.content.*
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

class TradingService : Service() {
    companion object {
        var isRunning = false
        var currentBalance = 0.0
        var logHistory = StringBuilder()
        var posicionAbierta = false
        var monedaConPosicion = ""
        var tipoPosicion = ""
        var precioEntrada = 0.0
        var lastPrice = "0.0"
        var lastRSI = "--"
        var currentStatus = "Iniciando..."
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val CHANNEL_ID_FOREGROUND = "SignalFusionChannel"
    private val CHANNEL_ID_ALERTS = "SignalFusionAlerts"
    private lateinit var manualCloseReceiver: BroadcastReceiver
    private var isReceiverRegistered = false

    private var targetTP = 6.0
    private var targetSL = 3.0
    private var leverage = 10.0
    private var riskPercent = 20.0
    private var activeStrategy = "MODERADA"
    private var candleTimeframe = "15m"
    private var candleIntervalMs = 900_000L
    private var lastCandleTime = 0L
    private var maxPnLAlcanzado = 0.0
    private var tsActivation = 2.5
    private var tsCallback = 0.6
    private var initialBalance = 0.0
    private var maxDailyLoss = 10.0
    private var apiKey = ""
    private var apiSecret = ""
    private var apiPassphrase = ""
    private var activeSymbols = mutableListOf<String>()
    private var currentSymbolIndex = 0
    private val historialPreciosMap = mutableMapOf<String, MutableList<Double>>()
    private var ultimaOperacionTime = 0L
    private var consecutiveLosses = 0
    private val baseCooldown = 900_000L
    private var lastHeartbeat = System.currentTimeMillis()
    private val heartbeatInterval = 300_000L
    private var errorCount = 0
    private val ultimateStrategies = mutableMapOf<String, SignalFusionUltimateStrategy>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        agregarLog("🔧 onCreate() llamado")
        crearCanalesNotificacion()
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "SignalFusion::TradingWakeLock")
        wakeLock?.acquire()
        agregarLog("⚡ WakeLock adquirido")

        manualCloseReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == "FORZAR_CIERRE_MANUAL") {
                    if (posicionAbierta) {
                        agregarLog("⚠️ PÁNICO: Ejecutando cierre...")
                        CoroutineScope(Dispatchers.IO).launch { cerrarTradeReal("Manual Panic") }
                    } else { actualizarEstadoUI("Limpiando UI...") }
                }
                if (intent?.action == "SOLICITAR_REFRESH_UI" || intent?.action == "SOLICITAR_REFRESH_BALANCE") {
                    CoroutineScope(Dispatchers.IO).launch {
                        obtenerBalanceBitget()?.let { currentBalance = it }
                        actualizarEstadoUI("Sincronizado")
                        cargarHistorialCerradas()
                    }
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction("FORZAR_CIERRE_MANUAL")
            addAction("SOLICITAR_REFRESH_UI")
            addAction("SOLICITAR_REFRESH_BALANCE")
        }
        ContextCompat.registerReceiver(this, manualCloseReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
        isReceiverRegistered = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        agregarLog("🚀 onStartCommand() llamado")
        sincronizarAjustes()
        CoroutineScope(Dispatchers.IO).launch {
            agregarLog("💰 Obteniendo balance de Bitget...")
            val saldo = obtenerBalanceBitget()
            if (saldo != null && saldo >= 0) {
                currentBalance = saldo
                if (initialBalance == 0.0) initialBalance = currentBalance
                isRunning = true
                agregarLog("✅ MOTOR V7.4 ACTIVO | Balance: $${"%.2f".format(currentBalance)}")
                agregarLog("📊 TP: ${"%.1f".format(targetTP)}% | SL: ${"%.1f".format(targetSL)}% | R:R ${"%.1f".format(targetTP / targetSL)}:1")
                agregarLog("🎯 Estrategia: $activeStrategy | Timeframe: $candleTimeframe")
                agregarLog("🪙 Monedas activas: ${activeSymbols.joinToString(", ")}")
                cargarHistorialCerradas()
                activeSymbols.forEach {
                    agregarLog("🔧 Configurando leverage para $it...")
                    setearLeverage(it, "LONG")
                }
                iniciarCicloTrading()
            } else {
                agregarLog("❌ ERROR: No se pudo obtener balance. Revisa API Keys")
                agregarLog("❌ Respuesta saldo: $saldo")
                stopSelf()
            }
        }
        startForeground(1, createForegroundNotification("SignalFusion V7.4", "Motor activo"))
        return START_STICKY
    }

    private suspend fun cargarHistorialCerradas() = withContext(Dispatchers.IO) {
        try {
            agregarLog("📥 Descargando historial de trades...")
            val endpoint = "/api/v2/mix/order/history-orders?productType=USDT-FUTURES&limit=100"
            val resp = BitgetUtils.authenticatedGet(endpoint, apiKey, apiSecret, apiPassphrase)

            if (resp != null) {
                val json = JSONObject(resp)
                val code = json.optString("code")
                if (code == "00000") {
                    val data = json.optJSONArray("data")
                    if (data != null && data.length() > 0) {
                        var wins = 0
                        var losses = 0
                        var dailyPnl = 0.0
                        val now = System.currentTimeMillis()
                        val unDiaMs = 24L * 60 * 60 * 1000L
                        val ultimas10 = mutableListOf<String>()

                        for (i in 0 until data.length()) {
                            val order = data.getJSONObject(i)
                            var pnl = order.optDouble("profit", 0.0)
                            if (pnl == 0.0) pnl = order.optDouble("realizedPL", 0.0)
                            if (pnl == 0.0) pnl = order.optDouble("netProfit", 0.0)

                            if (pnl != 0.0) {
                                if (pnl > 0) wins++ else losses++
                                val uTime = order.optLong("uTime", order.optLong("cTime", now))
                                if (now - uTime <= unDiaMs) dailyPnl += pnl
                                if (ultimas10.size < 10) {
                                    val symbol = order.optString("symbol", "?").replace("USDT", "")
                                    val side = order.optString("posSide", order.optString("side", "?")).uppercase()
                                    val icono = if (pnl > 0) "🟢" else "🔴"
                                    val signo = if (pnl > 0) "+" else ""
                                    ultimas10.add("$icono $symbol ($side): $signo$${"%.2f".format(pnl)}")
                                }
                            }
                        }

                        val total = wins + losses
                        val wr = if (total > 0) (wins.toDouble() / total) * 100 else 0.0
                        agregarLog("📊 Trades analizados: $total ($wins W / $losses L)")
                        agregarLog("📊 WIN RATE: ${"%.1f".format(wr)}%")
                        agregarLog("💰 PnL 24h: $${"%.2f".format(dailyPnl)}")
                        ultimas10.reversed().forEach { agregarLog(it) }

                        val intent = Intent("ACTUALIZACION_ESTADISTICAS")
                        intent.putExtra("WIN_RATE", "${"%.1f".format(wr)}%")
                        intent.putExtra("DAILY_PNL", dailyPnl)
                        sendBroadcast(intent)
                    } else {
                        agregarLog("📜 No hay historial de trades")
                        val intent = Intent("ACTUALIZACION_ESTADISTICAS")
                        intent.putExtra("WIN_RATE", "0.0%")
                        intent.putExtra("DAILY_PNL", 0.0)
                        sendBroadcast(intent)
                    }
                } else {
                    agregarLog("⚠️ Code error: $code - ${json.optString("msg")}")
                }
            } else {
                agregarLog("❌ Respuesta nula del servidor")
            }
        } catch (e: Exception) {
            agregarLog("⚠️ Error Historial: ${e.message}")
        }
    }

    private fun iniciarCicloTrading() {
        agregarLog("🔄 Iniciando ciclo de trading...")
        job = CoroutineScope(Dispatchers.IO).launch {
            agregarLog("📥 Descargando historial inicial de velas...")
            activeSymbols.forEach {
                agregarLog("⏬ Descargando $it...")
                descargarHistorialInicial(it)
                delay(500)
            }
            agregarLog("✅ Descarga de historial completada")

            while (isActive) {
                try {
                    val now = System.currentTimeMillis()
                    if (now - lastHeartbeat > heartbeatInterval) {
                        lastHeartbeat = now
                        agregarLog("💓 Heartbeat | Balance: $${"%.2f".format(currentBalance)}")
                    }
                    if (posicionAbierta) verificarIntegridadPosicion()
                    if (currentBalance > 0 && currentBalance < initialBalance * (1 - (maxDailyLoss / 100.0))) {
                        agregarLog("⛔ CIRCUIT BREAKER"); stopSelf(); break
                    }

                    val symbol = if (posicionAbierta) monedaConPosicion else activeSymbols[currentSymbolIndex]
                    val precio = obtenerPrecioReal(symbol)

                    if (precio > 0) {
                        lastPrice = precio.toString()
                        if (System.currentTimeMillis() - lastCandleTime >= candleIntervalMs) {
                            actualizarDatosVela(symbol, precio)
                            lastCandleTime = System.currentTimeMillis()
                        }
                        val hP = historialPreciosMap[symbol] ?: mutableListOf()

                        if (hP.size >= 50) {
                            if (!posicionAbierta) ejecutarEstrategiaUltimate(symbol, precio, hP)
                            else gestionarSalida(symbol, precio)
                        } else {
                            actualizarEstadoUI("📥 Calibrando $symbol (${hP.size}/50)")
                            agregarLog("📥 Calibrando $symbol: ${hP.size}/50 velas")
                        }
                    } else {
                        agregarLog("⚠️ Precio inválido para $symbol: $precio")
                    }

                    if (!posicionAbierta) currentSymbolIndex = (currentSymbolIndex + 1) % activeSymbols.size
                    errorCount = 0
                } catch (e: Exception) {
                    agregarLog("⚠️ Loop error: ${e.message}")
                    e.printStackTrace()
                    errorCount++
                    if (errorCount > 3) {
                        agregarLog("🚨 Demasiados errores, reiniciando...")
                        delay(5000)
                        stopSelf()
                        break
                    } else {
                        delay(5000)
                    }
                }
                delay(if (posicionAbierta) 2000 else 3000)
            }
        }
    }

    private fun ejecutarEstrategiaUltimate(symbol: String, precio: Double, hP: List<Double>) {
        agregarLog("🔍 === INICIO EVALUACIÓN $symbol ===")
        agregarLog("💵 Precio actual: $${"%.2f".format(precio)}")
        agregarLog("📊 Velas disponibles: ${hP.size}")

        if (System.currentTimeMillis() < ultimaOperacionTime) {
            val cooldownSec = (ultimaOperacionTime - System.currentTimeMillis()) / 1000
            actualizarEstadoUI("⏳ Cooldown: ${cooldownSec}s")
            agregarLog("⏳ Cooldown activo: ${cooldownSec}s restantes")
            agregarLog("🔍 === FIN EVALUACIÓN (Cooldown) ===")
            return
        }

        agregarLog("📈 Calculando ATR...")
        val atr = try {
            Indicadores.calcularATR(hP, 14)
        } catch (e: Exception) {
            agregarLog("❌ Error calculando ATR: ${e.message}")
            0.0
        }
        val atrPercent = (atr / precio) * 100
        agregarLog("📊 ATR: ${"%.4f".format(atr)} USD")
        agregarLog("📊 ATR%: ${"%.2f".format(atrPercent)}% (Mínimo requerido: 0.5%)")

        if (atrPercent < 0.5) {  // ✅ REDUCIDO PARA TESTING
            actualizarEstadoUI("⏸️ ATR Bajo (${"%.2f".format(atrPercent)}%)")
            agregarLog("⏸️ ATR muy bajo (${"%.2f".format(atrPercent)}%), esperando volatilidad...")
            agregarLog("🔍 === FIN EVALUACIÓN (ATR Bajo) ===")
            return
        }

        agregarLog("📈 ATR SUFICIENTE, calculando indicadores...")
        val rsi = Indicadores.calcularRSI(hP, 14)
        val emas = Indicadores.calcularEMAs(hP)
        val bb = Indicadores.calcularBollingerBands(hP)
        val macd = Indicadores.calcularMACD(hP)
        lastRSI = "%.0f".format(rsi)

        agregarLog("📊 RSI: ${"%.1f".format(rsi)}")
        agregarLog("📊 EMA12: ${"%.2f".format(emas.fast)} | EMA26: ${"%.2f".format(emas.slow)}")
        agregarLog("📊 EMA50: ${"%.2f".format(emas.mid)} | EMA200: ${"%.2f".format(emas.trend)}")
        agregarLog("📊 BB Superior: ${"%.2f".format(bb.first)} | Media: ${"%.2f".format(bb.second)} | Inferior: ${"%.2f".format(bb.third)}")
        agregarLog("📊 MACD: ${"%.2f".format(macd.first)} | Signal: ${"%.2f".format(macd.second)} | Hist: ${"%.2f".format(macd.third)}")

        actualizarEstadoUI("Analizando $symbol | RSI: $lastRSI | ATR: ${"%.2f".format(atrPercent)}%")

        val marketData = MarketData(precio, precio*1.005, precio*0.995, rsi, rsi, emas.fast, emas.slow, emas.mid, emas.trend, bb.first, bb.second, bb.third, macd.first, macd.second, macd.third)
        val cerebro = ultimateStrategies[symbol]

        if (cerebro == null) {
            agregarLog("❌ ERROR CRÍTICO: Estrategia no inicializada para $symbol")
            agregarLog("🔍 === FIN EVALUACIÓN (Sin estrategia) ===")
            return
        }

        agregarLog("🧠 Evaluando señal con estrategia $activeStrategy...")
        val senialFinal = cerebro.evaluate(marketData)
        agregarLog("📡 SEÑAL RECIBIDA: \"$senialFinal\"")

        if ((senialFinal == "LONG" || senialFinal == "SHORT") && !posicionAbierta) {
            agregarLog("✅✅✅ SEÑAL VÁLIDA DETECTADA: $senialFinal ✅✅✅")
            agregarLog("🚀 Procediendo a abrir trade...")
            posicionAbierta = true
            monedaConPosicion = symbol
            tipoPosicion = senialFinal
            abrirTradeReal(symbol, precio, senialFinal, hP)
        } else {
            if (senialFinal == "NEUTRAL") {
                agregarLog("⚪ Señal NEUTRAL - Sin condiciones para operar")
            } else if (posicionAbierta) {
                agregarLog("⚠️ Ya hay posición abierta, ignorando señal")
            } else {
                agregarLog("⚪ Señal: $senialFinal (no ejecutable)")
            }
        }
        agregarLog("🔍 === FIN EVALUACIÓN ===")
    }

    private fun gestionarSalida(symbol: String, precio: Double) {
        val pnlNeto = calcularPnL(precio, true)
        if (pnlNeto > maxPnLAlcanzado) maxPnLAlcanzado = pnlNeto
        actualizarEstadoUI("Operando: ${"%.2f".format(pnlNeto)}%")
        if (maxPnLAlcanzado >= tsActivation && (maxPnLAlcanzado - pnlNeto) >= tsCallback) {
            agregarLog("🛡️ Trailing Stop activado: Max ${"%.2f".format(maxPnLAlcanzado)}% → Actual ${"%.2f".format(pnlNeto)}%")
            cerrarTradeReal("Trailing Stop 🛡️")
        }
    }

    private fun abrirTradeReal(symbol: String, precio: Double, tipo: String, hP: List<Double>) {
        CoroutineScope(Dispatchers.IO).launch {
            agregarLog("🎯 === ABRIENDO TRADE ===")
            agregarLog("🎯 SEÑAL: $tipo ($symbol) @ $${"%.2f".format(precio)}")
            setearLeverage(symbol, tipo)

            // ⚠️ CORRECCIÓN CRÍTICA DE MARGEN:
            // Bitget exige un mínimo de 5 USDT nominales. Con tu balance de $14,
            // garantizamos que siempre use al menos 5.5 USD para superar la barrera.
            val margenDeseado = when {
                currentBalance < 15.0 -> min(currentBalance * 0.40, 5.5) // Aumentamos a 5.5 USD mínimo
                currentBalance < 20.0 -> min(currentBalance * 0.30, 6.0)
                currentBalance < 50.0 -> min(currentBalance * 0.15, 7.5)
                else -> currentBalance * (riskPercent / 100.0)
            }

            agregarLog("💰 Balance: $${"%.2f".format(currentBalance)}")
            agregarLog("💰 Margen deseado: $${"%.2f".format(margenDeseado)}")

            val sizeAmount = (margenDeseado * leverage) / precio // ⚠️ Multiplicado por el leverage para superar los 5 USDT
            agregarLog("📏 Size calculado (Nocional): ${"%.6f".format(sizeAmount)}")

            var precisionSize = 1; var precisionPrice = 2
            when {
                symbol.contains("BTC") -> { precisionSize = 3; precisionPrice = 1 }
                symbol.contains("ETH") -> { precisionSize = 2; precisionPrice = 2 }
                symbol.contains("SOL") -> { precisionSize = 1; precisionPrice = 2 }
                symbol.contains("XRP") -> { precisionSize = 0; precisionPrice = 4 }
            }

            val sizeStr = String.format(Locale.US, "%.${precisionSize}f", sizeAmount)
            val sizeFinal = sizeStr.toDoubleOrNull() ?: 0.0
            agregarLog("📏 Size formateado: $sizeStr (precision: $precisionSize decimales)")

            if (sizeFinal <= 0.0 || currentBalance <= 0.5) {
                agregarLog("⚠️ Saldo insuficiente para operar o Size = 0")
                agregarLog("⚠️ Size: $sizeFinal | Balance: $currentBalance")
                posicionAbierta = false
                monedaConPosicion = ""
                return@launch
            }

            val distanciaSL = precio * (targetSL / 100.0 / leverage)
            val distanciaTP = precio * (targetTP / 100.0 / leverage)
            val slPrice = if (tipo == "LONG") precio - distanciaSL else precio + distanciaSL
            val tpPrice = if (tipo == "LONG") precio + distanciaTP else precio - distanciaTP

            agregarLog("🎯 SL: $${"%.2f".format(slPrice)} (distancia: ${"%.2f".format(distanciaSL)})")
            agregarLog("🎯 TP: $${"%.2f".format(tpPrice)} (distancia: ${"%.2f".format(distanciaTP)})")
            agregarLog("🎯 Exposición total: $${"%.2f".format(margenDeseado * leverage)}")

            val json = JSONObject().apply {
                put("symbol", symbol)
                put("productType", "usdt-futures")
                put("marginCoin", "USDT")
                put("marginMode", "crossed")
                put("side", if (tipo == "LONG") "buy" else "sell")
                put("tradeSide", "open")
                put("orderType", "market")
                put("size", sizeStr)
                put("presetStopLossPrice", String.format(Locale.US, "%.${precisionPrice}f", slPrice))
                put("presetTakeProfitPrice", String.format(Locale.US, "%.${precisionPrice}f", tpPrice))
            }

            agregarLog("📤 Enviando orden a Bitget...")
            agregarLog("📋 Payload: ${json.toString()}")

            val resp = BitgetUtils.authenticatedPost("/api/v2/mix/order/place-order", json.toString(), apiKey, apiSecret, apiPassphrase)

            agregarLog("📥 Respuesta Bitget: ${resp?.take(200)}")

            if (resp != null && resp.contains("00000")) {
                delay(1500)
                precioEntrada = precio
                maxPnLAlcanzado = -0.2
                ultimaOperacionTime = System.currentTimeMillis() + baseCooldown
                agregarLog("✅✅✅ ORDEN EJECUTADA EXITOSAMENTE ✅✅✅")
                agregarLog("💰 Margen usado: $${"%.2f".format(margenDeseado)}")
                agregarLog("📊 Exposición: $${"%.2f".format(margenDeseado * leverage)}")
                agregarLog("⏱️ Cooldown hasta: ${SimpleDateFormat("HH:mm:ss").format(Date(ultimaOperacionTime))}")
                actualizarEstadoUI("🚀 POSICIÓN ACTIVA")
                TelegramNotifier.enviarEntrada(applicationContext, "$symbol (REAL 💰)", tipo, precio)
            } else {
                agregarLog("❌❌❌ ORDEN RECHAZADA ❌❌❌")
                agregarLog("❌ Respuesta completa: $resp")
                posicionAbierta = false
                monedaConPosicion = ""
            }
            agregarLog("🎯 === FIN APERTURA ===")
        }
    }

    private suspend fun setearLeverage(symbol: String, tipo: String) = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject().apply {
                put("symbol", symbol)
                put("productType", "USDT-FUTURES")
                put("marginCoin", "USDT")
                put("leverage", leverage.toInt().toString())
                put("holdSide", if (tipo == "LONG") "long" else "short")
            }
            val resp = BitgetUtils.authenticatedPost("/api/v2/mix/account/set-leverage", json.toString(), apiKey, apiSecret, apiPassphrase)
            agregarLog("🔧 Leverage configurado: ${leverage.toInt()}x para $symbol ($tipo)")
        } catch (e: Exception) {
            agregarLog("⚠️ Error configurando leverage: ${e.message}")
        }
    }

    private fun cerrarTradeReal(motivo: String) {
        CoroutineScope(Dispatchers.IO).launch {
            if (!posicionAbierta) return@launch
            agregarLog("📤 === CERRANDO TRADE ===")
            agregarLog("📤 Motivo: $motivo")
            val symTemp = monedaConPosicion; val sideTemp = tipoPosicion
            val json = JSONObject().apply {
                put("symbol", monedaConPosicion)
                put("productType", "usdt-futures")
                put("marginCoin", "USDT")
                put("holdSide", if (tipoPosicion == "LONG") "long" else "short")
            }
            val resp = BitgetUtils.authenticatedPost("/api/v2/mix/order/close-positions", json.toString(), apiKey, apiSecret, apiPassphrase)

            if (resp != null && (resp.contains("00000") || resp.contains("success"))) {
                val precioCierre = lastPrice.toDoubleOrNull() ?: precioEntrada
                val pnlFinal = calcularPnL(precioCierre, true)

                if (pnlFinal < 0) {
                    consecutiveLosses++
                    val cooldownMin = 15 + (consecutiveLosses * 10)
                    ultimaOperacionTime = System.currentTimeMillis() + (cooldownMin * 60_000L)
                    agregarLog("⏸️ Cooldown extendido: ${cooldownMin}min (pérdidas consecutivas: $consecutiveLosses)")
                } else {
                    consecutiveLosses = 0
                    ultimaOperacionTime = System.currentTimeMillis() + baseCooldown
                    agregarLog("✅ Cooldown normal: 15min (racha de pérdidas reseteada)")
                }

                posicionAbierta = false
                monedaConPosicion = ""
                maxPnLAlcanzado = 0.0
                obtenerBalanceBitget()?.let { currentBalance = it }
                agregarLog("🏁 TRADE CERRADO")
                agregarLog("💰 PnL: ${"%.2f".format(pnlFinal)}%")
                agregarLog("💰 Nuevo balance: $${"%.2f".format(currentBalance)}")
                actualizarEstadoUI("Escaneando...")
                TelegramNotifier.enviarSalida(applicationContext, symTemp, sideTemp, pnlFinal, precioCierre)
                cargarHistorialCerradas()
            } else {
                agregarLog("❌ ERROR AL CERRAR: $resp")
            }
            agregarLog("📤 === FIN CIERRE ===")
        }
    }

    private fun calcularPnL(actual: Double, conFees: Boolean): Double {
        if (precioEntrada <= 0) return 0.0
        val diff = if (tipoPosicion == "LONG") actual - precioEntrada else precioEntrada - actual
        val bruto = (diff / precioEntrada) * 100 * leverage
        return if (conFees) bruto - (0.12 * leverage) else bruto
    }

    private fun actualizarDatosVela(symbol: String, precio: Double) {
        val lista = historialPreciosMap[symbol] ?: return
        lista.add(precio)
        if (lista.size > 250) lista.removeAt(0)
    }

    private suspend fun descargarHistorialInicial(s: String) = withContext(Dispatchers.IO) {
        try {
            agregarLog("🔄 Descargando velas para $s...")
            val url = "https://api.bitget.com/api/v2/mix/market/candles?symbol=$s&productType=USDT-FUTURES&granularity=$candleTimeframe&limit=200"
            val body = client.newCall(Request.Builder().url(url).build()).execute().body?.string()

            if (body == null) {
                agregarLog("❌ $s: Respuesta nula de API")
                return@withContext
            }

            val data = JSONObject(body).getJSONArray("data")
            val precios = mutableListOf<Double>()
            for (i in data.length() - 1 downTo 0) {
                precios.add(data.getJSONArray(i).getString(4).toDouble())
            }
            historialPreciosMap[s] = precios
            agregarLog("✅ $s: ${precios.size} velas descargadas correctamente")
        } catch (e: Exception) {
            agregarLog("❌ Error descargando $s: ${e.message}")
            e.printStackTrace()
        }
    }

    private suspend fun verificarIntegridadPosicion() {
        try {
            val endpoint = "/api/v2/mix/position/single-position?symbol=$monedaConPosicion&productType=usdt-futures&marginCoin=USDT"
            val resp = BitgetUtils.authenticatedGet(endpoint, apiKey, apiSecret, apiPassphrase)
            if (resp != null) {
                val json = JSONObject(resp)
                if (json.optString("code") == "00000") {
                    val data = json.optJSONArray("data")
                    var isRealmenteAbierta = false

                    if (data != null) {
                        for (i in 0 until data.length()) {
                            val total = data.getJSONObject(i).optString("total", "0").toDoubleOrNull() ?: 0.0
                            if (total > 0.0) { isRealmenteAbierta = true; break }
                        }
                    }

                    if (!isRealmenteAbierta && posicionAbierta) {
                        agregarLog("⚠️ Posición cerrada externamente (TP/SL ejecutado)")
                        posicionAbierta = false
                        monedaConPosicion = ""
                        cargarHistorialCerradas()
                    }
                }
            }
        } catch (e: Exception) {
            agregarLog("⚠️ Error verificando posición: ${e.message}")
        }
    }

    private fun actualizarEstadoUI(mensaje: String) {
        val i = Intent("ACTUALIZACION_TRADING")
        i.putExtra("STATUS_MSG", mensaje)
        i.putExtra("BALANCE", currentBalance)
        i.putExtra("IS_TRADE_OPEN", posicionAbierta)
        if (posicionAbierta) {
            val pnl = calcularPnL(lastPrice.toDoubleOrNull() ?: precioEntrada, true)
            i.putExtra("TRADE_SYMBOL", monedaConPosicion)
            i.putExtra("TRADE_TYPE", tipoPosicion)
            i.putExtra("TRADE_PNL", pnl)
        }
        sendBroadcast(i)
    }

    private suspend fun obtenerBalanceBitget(): Double? = withContext(Dispatchers.IO) {
        try {
            val resp = BitgetUtils.authenticatedGet("/api/v2/mix/account/accounts?productType=USDT-FUTURES", apiKey, apiSecret, apiPassphrase)
            val bal = JSONObject(resp ?: "{}").getJSONArray("data").getJSONObject(0).getString("available").toDouble()
            getSharedPreferences("BotConfig", Context.MODE_PRIVATE).edit().putString("LAST_KNOWN_BALANCE", bal.toString()).apply()
            bal
        } catch (e: Exception) {
            agregarLog("⚠️ Error obteniendo balance: ${e.message}")
            null
        }
    }

    private suspend fun obtenerPrecioReal(s: String): Double = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.bitget.com/api/v2/mix/market/ticker?symbol=$s&productType=USDT-FUTURES"
            val body = client.newCall(Request.Builder().url(url).build()).execute().body?.string()
            JSONObject(body ?: "{}").getJSONArray("data").getJSONObject(0).getString("lastPr").toDouble()
        } catch (e: Exception) {
            0.0
        }
    }

    private fun sincronizarAjustes() {
        agregarLog("⚙️ Sincronizando configuración...")
        val p = getSharedPreferences("BotConfig", Context.MODE_PRIVATE)
        apiKey = p.getString("API_KEY", "") ?: ""
        apiSecret = p.getString("SECRET_KEY", "") ?: ""
        apiPassphrase = p.getString("API_PASSPHRASE", "") ?: ""

        leverage = 10.0
        riskPercent = 5.0
        targetTP = 6.0
        targetSL = 2.6
        candleTimeframe = "15m"
        activeStrategy = p.getString("STRATEGY", "MODERADA") ?: "MODERADA"
        candleIntervalMs = 900_000L

        activeSymbols.clear()
        if (p.getBoolean("COIN_BTC", true)) activeSymbols.add("BTCUSDT")
        if (p.getBoolean("COIN_ETH", false)) activeSymbols.add("ETHUSDT")
        if (p.getBoolean("COIN_SOL", false)) activeSymbols.add("SOLUSDT")
        if (p.getBoolean("COIN_XRP", false)) activeSymbols.add("XRPUSDT")
        if (activeSymbols.isEmpty()) activeSymbols.add("BTCUSDT")

        ultimateStrategies.clear()
        activeSymbols.forEach { symbol ->
            ultimateStrategies[symbol] = SignalFusionUltimateStrategy(candleTimeframe, activeStrategy)
            agregarLog("🧠 Estrategia $activeStrategy configurada para $symbol")
        }
        agregarLog("⚙️ Configuración sincronizada correctamente")
    }
    private fun agregarLog(m: String) {
        val timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val logLine = "[$timestamp] $m\n"
        logHistory.insert(0, logLine)
        sendBroadcast(Intent("ACTUALIZACION_TRADING").putExtra("LOG_MSG", m))
        // 👇 ESTA ES LA LÍNEA MÁGICA PARA VERLO EN EL PC 👇
        android.util.Log.d("BOT_DEBUG", m)
    }
    private fun crearCanalesNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val m = getSystemService(NotificationManager::class.java)
            m.createNotificationChannel(NotificationChannel(CHANNEL_ID_FOREGROUND, "Motor", NotificationManager.IMPORTANCE_LOW))
            m.createNotificationChannel(NotificationChannel(CHANNEL_ID_ALERTS, "Alertas", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    private fun createForegroundNotification(t: String, c: String): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID_FOREGROUND)
            .setContentTitle(t).setContentText(c).setSmallIcon(android.R.drawable.ic_menu_compass).setOngoing(true).setPriority(NotificationCompat.PRIORITY_MAX).setContentIntent(pendingIntent).build()
    }

    override fun onDestroy() {
        agregarLog("🛑 onDestroy() llamado - Deteniendo servicio")
        isRunning = false
        job?.cancel()
        try { wakeLock?.release() } catch (e: Exception) {}
        if (isReceiverRegistered) unregisterReceiver(manualCloseReceiver)
        super.onDestroy()
    }
}